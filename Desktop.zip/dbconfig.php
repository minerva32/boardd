<?php
	$db = new mysqli('localhost', 'dongkyu', 'ubuntu', 'test');

	if($db->connect_error) {

		die('Database error!\nAdmin call!');
	}

	$db->set_charset('utf8');

?>
